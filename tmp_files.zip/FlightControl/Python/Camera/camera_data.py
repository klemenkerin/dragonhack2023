```
# camera_data.py

class Camera:
    def __init__(self, image_data):
        self.image_data = image_data

    def process_data(self):
        # processing logic here
        result = "Processed image data"
        return result
```