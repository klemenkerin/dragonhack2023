```
# gps_data.py

class GPS:
    def __init__(self, latitude, longitude):
        self.latitude = latitude
        self.longitude = longitude

    def process_data(self):
        # processing logic here
        result = f"Latitude: {self.latitude}, Longitude: {self.longitude}"
        return result
```