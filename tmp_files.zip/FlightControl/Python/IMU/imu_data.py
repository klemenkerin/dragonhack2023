```
# imu_data.py

class IMU:
    def __init__(self, accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z):
        self.accel_x = accel_x
        self.accel_y = accel_y
        self.accel_z = accel_z
        self.gyro_x = gyro_x
        self.gyro_y = gyro_y
        self.gyro_z = gyro_z

    def process_data(self):
        # processing logic here
        result = self.accel_x + self.gyro_x
        return result
```