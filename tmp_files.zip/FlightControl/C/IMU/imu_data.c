```
// imu_data.c

#include "imu_data.h"

int process_data(int accel_x, int accel_y, int accel_z, int gyro_x, int gyro_y, int gyro_z) {
    // processing logic here
    int result = accel_x + gyro_x;
    return result;
}
```